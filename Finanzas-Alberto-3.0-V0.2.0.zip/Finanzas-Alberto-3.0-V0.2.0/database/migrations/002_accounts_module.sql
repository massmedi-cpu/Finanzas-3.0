-- Finanzas Alberto 3.0
-- V0.2.0 Sistema de cuentas

create table if not exists accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  nombre text not null,
  entidad text,
  tipo text not null,
  moneda text default 'EUR',
  saldo_inicial numeric default 0,
  activo boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists accounts_user_id_idx
on accounts(user_id);

alter table accounts enable row level security;

create policy "users_manage_own_accounts"
on accounts
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
