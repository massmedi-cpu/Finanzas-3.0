# Finanzas Alberto 3.0

## V0.2.0

Sistema de cuentas implementado:

- Tabla accounts
- Servicio cuentas
- Componentes frontend
- Seguridad RLS
