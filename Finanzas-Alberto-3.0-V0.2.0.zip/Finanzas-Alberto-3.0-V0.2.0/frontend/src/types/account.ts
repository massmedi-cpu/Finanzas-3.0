export type Account = {
  id: string
  user_id: string
  nombre: string
  entidad?: string
  tipo: string
  moneda: string
  saldo_inicial: number
  activo: boolean
}
