import type { Account } from "@/types/account"
import AccountCard from "./AccountCard"

export default function AccountList({accounts}:{accounts:Account[]}) {
  return (
    <section>
      {accounts.map(account =>
        <AccountCard key={account.id} account={account}/>
      )}
    </section>
  )
}
