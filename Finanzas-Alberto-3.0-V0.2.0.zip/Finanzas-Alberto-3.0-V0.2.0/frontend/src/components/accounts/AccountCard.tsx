import type { Account } from "@/types/account"

export default function AccountCard({account}:{account:Account}) {
  return (
    <div>
      <h3>{account.nombre}</h3>
      <p>{account.entidad}</p>
      <strong>{account.saldo_inicial} {account.moneda}</strong>
    </div>
  )
}
