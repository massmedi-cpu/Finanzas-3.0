import { getAccounts } from "@/services/accounts"

export default async function AccountsPage() {
  const accounts = await getAccounts()

  return (
    <main>
      <h1>Mis cuentas</h1>
      <p>Total cuentas: {accounts.length}</p>
    </main>
  )
}
