import { supabase } from "@/lib/supabase"
import type { Account } from "@/types/account"

export async function getAccounts() {
  const { data, error } = await supabase
    .from("accounts")
    .select("*")
    .eq("activo", true)

  if (error) throw error

  return data as Account[]
}

export async function createAccount(account: Partial<Account>) {
  const { data, error } = await supabase
    .from("accounts")
    .insert(account)
    .select()
    .single()

  if (error) throw error

  return data as Account
}
